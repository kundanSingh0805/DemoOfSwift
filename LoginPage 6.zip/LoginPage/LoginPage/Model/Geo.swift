//
//  Geo.swift
//  LoginPage
//
//  Created by IE15 on 24/11/23.
//

import Foundation
struct Geo: Codable {
    let lat: String
    let lng: String
}

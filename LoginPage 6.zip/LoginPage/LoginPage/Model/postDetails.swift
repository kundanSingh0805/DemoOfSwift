//
//  postDetails.swift
//  LoginPage
//
//  Created by IE15 on 27/11/23.
//

import Foundation
struct PostDetails: Codable{
    let userId: Int
    let id : Int
    let title: String
    let body: String
}

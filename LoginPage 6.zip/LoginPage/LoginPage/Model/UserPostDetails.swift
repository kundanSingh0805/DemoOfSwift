//
//  userPostDetails.swift
//  LoginPage
//
//  Created by IE15 on 24/11/23.
//

import Foundation

struct UserPostDetails: Codable {
    
    let userId: Int
    let id: Int
    let title: String
    let body: String
}

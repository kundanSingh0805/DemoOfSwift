//
//  Company.swift
//  LoginPage
//
//  Created by IE15 on 24/11/23.
//

import Foundation
struct Company: Codable {

    let name: String
    let catchPhrase: String
   let bs: String

}

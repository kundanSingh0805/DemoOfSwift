//
//  PostUserDetails.swift
//  LoginPage
//
//  Created by IE15 on 28/11/23.
//

import Foundation
struct ThisPostShareBY: Codable {
    let postId: Int
    let id: Int
    let name: String
    let email: String
    let body: String
}

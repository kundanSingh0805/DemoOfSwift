//
//  Address.swift
//  LoginPage
//
//  Created by IE15 on 24/11/23.
//

import Foundation
struct Address: Codable {

    let street: String
    let suite: String
    let city: String
    let zipcode: String
    let geo: Geo

}

//
//  RootClass.swift
//
//  Generated using https://jsonmaster.github.io
//  Created on November 24, 2023
//
import Foundation

struct RootClass: Codable {

	let postId: Int
	let id: Int
	let name: String
	let email: String
	let body: String

}
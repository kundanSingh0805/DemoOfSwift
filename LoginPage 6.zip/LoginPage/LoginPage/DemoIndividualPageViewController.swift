//
//  DemoIndividualPageViewController.swift
//  LoginPage
//
//  Created by IE15 on 04/11/23.
//

import UIKit

class DemoIndividualPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}

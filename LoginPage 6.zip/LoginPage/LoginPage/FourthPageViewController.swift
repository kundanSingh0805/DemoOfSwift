//
//  FourthPageViewController.swift
//  LoginPage
//
//  Created by IE15 on 06/11/23.
//

import UIKit

class FourthPageViewController: UIPageViewController {

    @IBOutlet weak var image: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        if let yourImage: UIImage = UIImage(named: "team.png") {
            image.image = yourImage
        }
    }
}

//
//  BirthdayViewController.swift
//  LoginPage
//
//  Created by IE15 on 06/11/23.
//

import UIKit

class BirthdayViewController: UIViewController {
    var datePicked: Bool = false

    @IBOutlet private var nextPageButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        nextPageButton.layer.cornerRadius = 8
        navigationTitle()
    }

    private func navigationTitle() {
        let fontSize: CGFloat = 25.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Coders Mood"
    }

    private func alertMassage(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in
            // print("OK Tapped")
        }))
        self.present(alertController, animated: true)
    }

    @IBAction private func dateAction(_ sender: UIDatePicker) {
        datePicked = true
    }

    @IBAction private func continueAction(_ sender: Any) {
        guard datePicked else {
            alertMassage(title: "Invalid date", message: "Please select you birthday date")
            return
        }
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let genderViewController = storyboard.instantiateViewController(withIdentifier: "GenderViewController")
        navigationController?.pushViewController(genderViewController, animated: true)
    }
}

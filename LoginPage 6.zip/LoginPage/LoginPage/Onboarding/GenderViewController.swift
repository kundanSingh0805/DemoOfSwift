//
//  GenderViewController.swift
//  LoginPage
//
//  Created by IE15 on 06/11/23.
//

import UIKit

class GenderViewController: UIViewController {
    @IBOutlet private var maleButton: UIButton!
    @IBOutlet private var femaleButton: UIButton!
    @IBOutlet private var nextPageButton: UIButton!
    var isMale: Bool?

    let brownColor: UIColor = UIColor(red: 199/255, green: 190/255, blue: 189/255, alpha: 0.5)
    let whiteColor: UIColor = UIColor(red: 232/255, green: 236/255, blue: 237/255, alpha: 0.5)

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationTitle()
        buttonBorder(button: maleButton)
        buttonBorder(button: femaleButton)
        nextPageButton.layer.cornerRadius = 8
        femaleButton.layer.cornerRadius = 8
        maleButton.layer.cornerRadius = 8
        navigationItem.hidesBackButton = true
    }

    private func buttonBorder(button: UIButton) {
        button.layer.borderColor = UIColor.black.cgColor
        button.layer.borderWidth = 1.5
        button.frame = CGRect(x: 100, y: 100, width: 200, height: 40)
    }

    private func navigationTitle() {
        let fontSize: CGFloat = 30.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Coders Mood"
    }

    @IBAction private func maleAction(_ sender: Any) {
        isMale = true
        maleButton.backgroundColor = brownColor
        femaleButton.backgroundColor = whiteColor
    }

    @IBAction private func femaleAction(_ sender: Any) {
        isMale = false
        femaleButton.backgroundColor = brownColor
        maleButton.backgroundColor = whiteColor
    }

    @IBAction private func continueAction(_ sender: Any) {
        guard isMale != nil else {
        let alertController = UIAlertController(title: "Invalid gender",
                                                message: "Please select your gender", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in }))
        self.present(alertController, animated: true)
        return
        }

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let congratulationViewController =
        storyboard.instantiateViewController(withIdentifier: "HomeTabBarController")
        navigationController?.pushViewController(congratulationViewController, animated: true)
        return
    }
}

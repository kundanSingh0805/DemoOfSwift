//
//  ViewController.swift
//  LoginPage
//
//  Created by IE15 on 02/11/23.
//
import LocalAuthentication
import UIKit
import Keychain

class SignInViewController: UIViewController {
    @IBOutlet private var emailTextField: UITextField!
    @IBOutlet private var passwordTextField: UITextField!
    @IBOutlet private var showHideIconChangePasswordButton: UIButton!
    @IBOutlet private var checkBoxButton: UIButton!
    @IBOutlet private var biometryTypeButton: UIButton!
    @IBOutlet private var signInButton: UIButton!

    private var isShow = true
    private var isChecked = false

    override func viewDidLoad() {
        super.viewDidLoad()
         navigationTitle()
          configureTextFieldWithLeftPadding(emailTextField, padding: 10)
        configureTextFieldWithLeftPadding(passwordTextField, padding: 10)
        textFieldBorder(textField: emailTextField)
        textFieldBorder(textField: passwordTextField)
        navigationItem.hidesBackButton = true
        signInButton.layer.cornerRadius = 8
        let context = LAContext()
        var error: NSError?

        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            let biometryType = context.biometryType

            switch biometryType {
            case .none:
                biometryTypeButton.isHidden = true
            case .touchID:
                let image = UIImage(systemName: "touchid")
                biometryTypeButton.setImage(image, for: .normal)
            case .faceID:
                let image = UIImage(systemName: "faceid")
                biometryTypeButton.setImage(image, for: .normal)
            @unknown default:
                biometryTypeButton.isHidden = true
            }
        } else {
            biometryTypeButton.isHidden = true
        }
        if let email = emailTextField, let password = passwordTextField {
            email.delegate = self
            password.delegate = self
        }

        func configureTextFieldWithLeftPadding(_ textField: UITextField, padding: CGFloat) {
                let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: padding, height: textField.frame.height))
                textField.leftView = paddingView
                textField.leftViewMode = .always
            }
    }

    @IBAction private func showHidePasswordAction(_ sender: Any) {
        if isShow {
            let image2 = UIImage(systemName: "eye.fill")
            showHideIconChangePasswordButton.setImage(image2, for: .normal)
            isShow = false
        } else {
            let image2 = UIImage(systemName: "eye.slash.fill")
            showHideIconChangePasswordButton.setImage(image2, for: .normal)
            isShow = true
        }
        passwordTextField.isSecureTextEntry = isShow
    }

    @IBAction private func checkBoxAction(_ sender: Any) {
        if isChecked {
            let image2 = UIImage(named: "UnCkeckedCheckBox")
            checkBoxButton.setImage(image2, for: .normal)
        } else {
            let image2 = UIImage(named: "ChechedCheckBox")
            checkBoxButton.setImage(image2, for: .normal)
        }
        isChecked = !isChecked
    }

    @IBAction private func signInAction(_ sender: Any) {
        guard let email = emailTextField.text, isValidEmail(email) else {
            let forEmptyEmail = "Please Enter your Email"
            alertMassage(title: "Invalid Email", message: forEmptyEmail)
            return
        }
        guard isValidPassword(mypassword: passwordTextField.text ?? "") else {
            let title = "Invalid Password"
            let message = """
Please enter right password :-
8 characters long, 1 uppercase, 1 lowercase character & 1 number
"""
            alertMassage(title: title, message: message)
            return
        }
        storeLocalyByRememberMe()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let tabBarController = storyboard.instantiateViewController(withIdentifier: "HomeTabBarController")
        navigationController?.pushViewController(tabBarController, animated: true)
    }

    @IBAction private func forgotPasswordAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let forgotPasswordController =
                storyboard.instantiateViewController(withIdentifier:
"ForgetPasswordViewController") as? ForgetPasswordViewController else {
            return }
        navigationController?.pushViewController(forgotPasswordController, animated: true)
    }
}

extension SignInViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    textField.resignFirstResponder()
        return true
    }

    @IBAction private func authenticateTapped(_ sender: Any) {
        let context = LAContext()
        var error: NSError?

        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            let reason = "Identify yourself!"

            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,
                                   localizedReason: reason) { [weak self] success, _ in
                DispatchQueue.main.async { [self] in
                    if success {
                        let isCheck = UserDefaults.standard.bool(forKey: "checkBox")
                        let email =  Keychain.load("email") // KeychainWrapper.standard.string(forKey: "email")
                        let password = Keychain.load("password") // KeychainWrapper.standard.string(forKey: "password")

                        if isCheck {
                            let image2 = UIImage(named: "Checked-removebg-preview")
                            self?.checkBoxButton.setImage(image2, for: .normal)
                            self?.emailTextField.text = email
                            self?.passwordTextField.text = password
                            self?.isChecked = true
                        }
                    } else {
                        let title = "Problem"
                        let massage = "Your identity is not match. please enter your Email and Password"
                        self?.alertMassage(title: title, message: massage)
                        return
                    }
                }
            }
        } else {
            // no biometry
        }
    }
}

extension SignInViewController {
    private func navigationTitle() {
        let fontSize: CGFloat = 30.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Coders Mood"
    }

    private func textFieldBorder(textField: UITextField) {
        textField.frame = CGRect(x: 50, y: 100, width: 200, height: 30)
        textField.borderStyle = .roundedRect
        textField.layer.borderColor = UIColor.gray.cgColor
        textField.layer.borderWidth = 1.5
        textField.layer.cornerRadius = 8
    }
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }

    private func isValidPassword(mypassword: String) -> Bool {
        let passwordreg = "(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z])(?=.*[@#$%^&*]).{8,}"
        let passwordtesting = NSPredicate(format: "SELF MATCHES %@", passwordreg)
        return passwordtesting.evaluate(with: mypassword)
    }

    private func storeLocalyByRememberMe() {
        UserDefaults.standard.set(isChecked, forKey: "checkBox")
        Keychain.save(emailTextField.text ?? "", forKey: "email")
        Keychain.save(passwordTextField.text ?? "", forKey: "password")
//        KeychainWrapper.standard.set(emailTextField.text ?? "", forKey: "email")
//        KeychainWrapper.standard.set(passwordTextField.text ?? "", forKey: "password")
    }

    private func alertMassage(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in
            // print("OK Tapped")
        }))
        self.present(alertController, animated: true)
    }

}
extension SignInViewController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        scrollView.contentOffset.x = 0.0
    }
}

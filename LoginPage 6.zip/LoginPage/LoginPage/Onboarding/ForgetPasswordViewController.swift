//
//  ForgetPasswordViewController.swift
//  LoginPage
//
//  Created by IE15 on 03/11/23.
//

import UIKit

class ForgetPasswordViewController: UIViewController {
    @IBOutlet private var userEmailTextField: UITextField!
    @IBOutlet private var nextPageButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationTitle()
        textFieldBorder(textField: userEmailTextField)
        configureTextFieldWithLeftPadding(userEmailTextField, padding: 10)
      nextPageButton.layer.cornerRadius = 8
        userEmailTextField.delegate = self
    }
    
    private func textFieldBorder(textField: UITextField) {
        textField.frame = CGRect(x: 50, y: 100, width: 200, height: 30)
        textField.borderStyle = .roundedRect
        textField.layer.borderColor = UIColor.gray.cgColor
        textField.layer.borderWidth = 1.5
        textField.layer.cornerRadius = 8
    }
    
    func configureTextFieldWithLeftPadding(_ textField: UITextField, padding: CGFloat) {
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: padding, height: textField.frame.height))
            textField.leftView = paddingView
            textField.leftViewMode = .always
        }
    private func navigationTitle() {
        let fontSize: CGFloat = 25.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Coders Mood"
    }

    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }

    private func alertMassage(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in
            // print("OK Tapped")
        }))
        self.present(alertController, animated: true)
    }

    @IBAction private func resetAction(_ sender: Any) {
        if !isValidEmail(userEmailTextField.text ?? "") {
            let alertController = UIAlertController(title: "Invalid Email",
                                                    message: "Please enter right email", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in }))
            self.present(alertController, animated: true)
            return
        }

        let alertController = UIAlertController(title: "Password Reset",
                                            message: "Please checK in your email for confirmation",
                                                preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .cancel,
                                                handler: { _ in }))
        self.present(alertController, animated: true)
        return
    }
    @IBAction private func backButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let tabBarController = storyboard.instantiateViewController(withIdentifier: "SignInViewController")
        navigationController?.pushViewController(tabBarController, animated: true)
    }
}

extension ForgetPasswordViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        userEmailTextField.resignFirstResponder()
        return true
    }
}

//
//  SignUpViewController.swift
//  LoginPage
//
//  Created by IE15 on 02/11/23.
//

import UIKit

class SignUpViewController: UIViewController {
    @IBOutlet private var userNameTextField: UITextField!
    @IBOutlet private var userEmailTextFiled: UITextField!
    @IBOutlet private var passwordTextField: UITextField!
    @IBOutlet private var showHideIconChangePasswordButton: UIButton!
    @IBOutlet private var showHideIconChangeConfirmPasswordButton: UIButton!
    @IBOutlet private var confirmPasswordTextField: UITextField!
    @IBOutlet private var signUpButton: UIButton!
   // @IBOutlet private var signInButton: UIButton!
    private var isShowForPassword = true
    private var isShowForConfirmPassword = true
    override func viewDidLoad() {
        super.viewDidLoad()
         navigationTitle()
        navigationItem.hidesBackButton = true
        textFieldBorder(textField: userNameTextField)
        textFieldBorder(textField: userEmailTextFiled)
        textFieldBorder(textField: passwordTextField)
        textFieldBorder(textField: confirmPasswordTextField)
        configureAllTextFieldWithLeftPadding()
        signUpButton.layer.cornerRadius = 8
        if let userName = userNameTextField, let userEmail = userEmailTextFiled,
            let password = passwordTextField, let confirmPassword = confirmPasswordTextField {
            password.delegate = self
            userName.delegate = self
            userEmail.delegate = self
            confirmPassword.delegate = self
        }
    }
    
    private func configureAllTextFieldWithLeftPadding(){
        configureTextFieldWithLeftPadding(userEmailTextFiled, padding: 10)
        configureTextFieldWithLeftPadding(userNameTextField, padding: 10)
        configureTextFieldWithLeftPadding(passwordTextField, padding: 10)
        configureTextFieldWithLeftPadding(confirmPasswordTextField, padding: 10)
    }
    private func configureTextFieldWithLeftPadding(_ textField: UITextField, padding: CGFloat) {
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: padding, height: textField.frame.height))
            textField.leftView = paddingView
            textField.leftViewMode = .always
        }
    
    @IBAction private func showHidePasswordAction(_ sender: Any) {
        if isShowForPassword {
            passwordTextField.isSecureTextEntry = false
            let image2 = UIImage(systemName: "eye.fill")
            showHideIconChangePasswordButton.setImage(image2, for: .normal)
        } else {
            passwordTextField.isSecureTextEntry = true
            let image2 = UIImage(systemName: "eye.slash.fill")
            showHideIconChangePasswordButton.setImage(image2, for: .normal)
        }
        isShowForPassword = !isShowForPassword
    }

    @IBAction private func showHideConfirmPasswordAction(_ sender: Any) {
        if isShowForConfirmPassword {
            confirmPasswordTextField.isSecureTextEntry = false
            let image2 = UIImage(systemName: "eye.fill")
            showHideIconChangeConfirmPasswordButton.setImage(image2, for: .normal)
        } else {
            confirmPasswordTextField.isSecureTextEntry = true
            let image2 = UIImage(systemName: "eye.slash.fill")
            showHideIconChangeConfirmPasswordButton.setImage(image2, for: .normal)
        }
        isShowForConfirmPassword = !isShowForConfirmPassword
    }

    @IBAction private func signUpAtion(_ sender: Any) {
        if !isValidName(userNameTextField.text ?? "") {
            let massage = "Please enter your full name"
            alertyMassage(title: "Invalid Name", massage: massage)
            return
        }
        if !isValidEmail(userEmailTextFiled.text ?? "") {
            let massage = "Please enter proper email address"
            alertyMassage(title: "Invalid Email", massage: massage)
            return
        }
        if !isValidPassword(myPassword: passwordTextField.text ?? "") {
            let massage =
            " please enter right password :- 8 characters long, 1 uppercase, 1 lowercase character & 1 number"
            alertyMassage(title: "Invalid Password", massage: massage)
            return
        }
        if passwordTextField.text != confirmPasswordTextField .text {
            let massage = "Your password is not matched"
            alertyMassage(title: "Confirm Password", massage: massage)
            return
        }

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let contactNumberViewController =
        storyboard.instantiateViewController(withIdentifier: "ContactNumberViewController")
        navigationController?.pushViewController(contactNumberViewController, animated: true)
    }
    
    @IBAction private func signInAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}

extension SignUpViewController {
    private func textFieldBorder(textField: UITextField) {
        textField.frame = CGRect(x: 50, y: 100, width: 200, height: 30)
        textField.borderStyle = .roundedRect
        textField.layer.borderColor = UIColor.gray.cgColor
        textField.layer.borderWidth = 1.5
        textField.layer.cornerRadius = 8
    }
    
    private func navigationTitle() {
        let fontSize: CGFloat = 30.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Coders Mood"
    }
    func alertyMassage(title: String?, massage: String?) {
        let alertController = UIAlertController(title: title, message: massage, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in }))
        self.present(alertController, animated: true)
    }

    func isValidName(_ name: String) -> Bool {
        let nameRegEx = "^[A-Za-z][A-Za-z0-9_ ]{7,29}$"
        let emailPred = NSPredicate(format: "SELF MATCHES %@", nameRegEx)
        return emailPred.evaluate(with: name)
    }
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }

    func isValidPassword(myPassword: String) -> Bool {
        let passwordreg = ("(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z])(?=.*[@#$%^&*]).{8,}")
        let passwordtesting = NSPredicate(format: "SELF MATCHES %@", passwordreg)
        return passwordtesting.evaluate(with: myPassword)
    }
}

extension SignUpViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        userNameTextField.resignFirstResponder()
        userEmailTextFiled.resignFirstResponder()
        passwordTextField.resignFirstResponder()
        confirmPasswordTextField.resignFirstResponder()
        return true
    }
}

extension SignUpViewController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        scrollView.contentOffset.x = 0.0
    }
}

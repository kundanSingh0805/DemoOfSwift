//
//  CongratulationViewController.swift
//  LoginPage
//
//  Created by IE15 on 06/11/23.
//

import UIKit

class CongratulationViewController: UIViewController {
    @IBOutlet private var nextPageButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        navigationTitle()
    }

    private func navigationTitle() {
        let fontSize: CGFloat = 30.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Coders Mood"
    }
}

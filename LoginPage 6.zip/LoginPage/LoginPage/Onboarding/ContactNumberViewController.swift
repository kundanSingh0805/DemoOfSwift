//
//  ContactNumberViewController.swift
//  LoginPage
//
//  Created by IE15 on 06/11/23.
//

import UIKit

class ContactNumberViewController: UIViewController {
    @IBOutlet private var contactNumberTextField: UITextField!
    @IBOutlet private var nextPageButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        navigationTitle()
       configureTextFieldWithLeftPadding(contactNumberTextField, padding: 10)
        nextPageButton.layer.cornerRadius = 8
        textFieldBorder(textField: contactNumberTextField)
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0,
                                                                  width: UIScreen.main.bounds.width, height: 50))
        doneToolbar.barStyle = .default
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self,
                                                    action: #selector(self.doneButtonAction))
        let items = [flexSpace, done]
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        contactNumberTextField.inputAccessoryView = doneToolbar
    }
    
    private func textFieldBorder(textField: UITextField) {
        textField.frame = CGRect(x: 50, y: 100, width: 200, height: 30)
        textField.borderStyle = .roundedRect
        textField.layer.borderColor = UIColor.gray.cgColor
        textField.layer.borderWidth = 1.5
        textField.layer.cornerRadius = 8
    }
    func configureTextFieldWithLeftPadding(_ textField: UITextField, padding: CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: padding, height: textField.frame.height))
        textField.leftView = paddingView
        textField.leftViewMode = .always
    }
    @objc func doneButtonAction() {
        contactNumberTextField.resignFirstResponder()
    }

    private func navigationTitle() {
        let fontSize: CGFloat = 25.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Coders Mood"
    }

    private func alertMassage(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in
            // print("OK Tapped")
        }))
        self.present(alertController, animated: true)
    }

    private func isValidateMobileNumber(value: String) -> Bool {
        let phoneRegex = "^[0-9+]{0,1}+[0-9]{9}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        let result = phoneTest.evaluate(with: value)
        return result
    }
    
    @IBAction private func continueAction(_ sender: Any) {
        guard  isValidateMobileNumber(value: contactNumberTextField.text ?? "") else {
            alertMassage(title: "Invalid Number", message: "Please enter your contact number")
            return
        }
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let birthdayViewController = storyboard.instantiateViewController(withIdentifier: "BirthdayViewController")
        navigationController?.pushViewController(birthdayViewController, animated: true)
    }
}

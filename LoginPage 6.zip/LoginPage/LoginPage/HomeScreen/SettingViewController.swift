////
////  SettingViewController.swift
////  LoginPage
////
////  Created by IE15 on 09/11/23.
////
//
// import UIKit
//
// final class SettingViewController: UIViewController {
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        navigationItem.hidesBackButton = true
//    }
//
//    @IBAction private func logOutAction(_ sender: Any) {
//        let alertController = UIAlertController(title: "Log Out",
// message: "You will be returned to the Login  screen", preferredStyle: .alert)
//        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in }))
//
//        let logOutActionButton = UIAlertAction(title: "Log out", style: .default, handler: { _ in
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//            let signInViewController = storyboard.instantiateViewController(withIdentifier: "SignInViewController")
//            guard let selfNavigationController = self.navigationController else {
//                return }
//            for controller in selfNavigationController.viewControllers as Array {
//                if controller.isKind(of: SignInViewController.self) {
//                    selfNavigationController.popToViewController(controller, animated: true)
//                    break
//                }
//            }
//        })
//
//        logOutActionButton.setValue(UIColor.red, forKey: "titleTextColor")
//        alertController.addAction(logOutActionButton)
//        self.present(alertController, animated: true)
//    }
// }

//
//  CalculatorViewController.swift
//  LoginPage
//
//  Created by IE15 on 08/11/23.
//

import UIKit

final class CalculatorViewController: UIViewController {
    @IBOutlet private var clearButton: UIButton!
    @IBOutlet private var answerLabel: UILabel!

    private var firstOperand: Double = 0.0
    private var secondOperand: Double = 0.0
    private var currentOperator: String = ""
    private var clearScreenForSecondOperand: Bool = false
    private var secondOperandChecker = false

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationTitle()
        navigationItem.leftBarButtonItem?.tintColor = UIColor.black
    }
    
    private func navigationTitle() {
        let fontSize: CGFloat = 25.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Calculator"
    }
    private func finalAnswer(ans: Double) {
        clearScreenForSecondOperand = true
        let finalValue: Double = Double(String(format: "%.2f", ans)) ?? 0.0
        if Double(Int(finalValue)) == finalValue {
            answerLabel.text = String(Int(ans))
        } else {
            answerLabel.text = String(finalValue)
        }
        firstOperand = Double(answerLabel.text ?? "0") ?? 0
    }

    @IBAction private func clearAction(_ sender: Any) {
        firstOperand = 0
        secondOperand = 0
        answerLabel.text = "0"
        clearScreenForSecondOperand = false
        currentOperator = ""
    }

    @IBAction private func signChangeAction(_ sender: Any) {
        if let number = Double(answerLabel.text ?? "") {
            if number != 0 {
                finalAnswer(ans: number * -1)
            }
        }
    }

    @IBAction private func percentageAction(_ sender: Any) {
        let percentageNumber: Double = Double(answerLabel.text ?? "0") ?? 0 / 100
        answerLabel.text = String(format: "%.2f", percentageNumber)
        clearScreenForSecondOperand = true
    }

    @IBAction private func numberAction(_ sender: UIButton) {
        secondOperandChecker = true
        if clearScreenForSecondOperand {
            answerLabel.text = ""
            clearScreenForSecondOperand = false
        }
        let number: Int = sender.tag
        if answerLabel.text == "0" {
            answerLabel.text = "\(number)"
            return
        }
        answerLabel.text = "\(answerLabel.text ?? "0")\(number)"
    }

    @IBAction private func divisionAction(_ sender: Any) {
        currentOperator = "/"
        guard secondOperandChecker else {
            return
        }
        secondOperandChecker = false
        if firstOperand == 0 {
            firstOperand = Double(answerLabel.text ?? "0") ?? 0
            finalAnswer(ans: firstOperand)
            return
        }
        secondOperand = Double(answerLabel.text ?? "0") ?? 0
        secondOperand = secondOperand == 0 ? 1 : secondOperand
        firstOperand /= secondOperand
        finalAnswer(ans: firstOperand)
        currentOperator = "/"
    }

    @IBAction private func multiplicationAction(_ sender: Any) {
        currentOperator = "*"
        guard secondOperandChecker else {
            return
        }
        secondOperandChecker = false
        if firstOperand == 0 {
            firstOperand = Double(answerLabel.text ?? "0") ?? 0
            finalAnswer(ans: firstOperand)
            return
        }
        secondOperand = Double(answerLabel.text ?? "0") ?? 0
        secondOperand = secondOperand == 0 ? 1 : secondOperand
        firstOperand *= secondOperand
        finalAnswer(ans: firstOperand)
        currentOperator = "*"
    }

    @IBAction private func additionAction(_ sender: Any) {
        currentOperator = "+"
        guard secondOperandChecker else {
            return
        }
        secondOperandChecker = false
        if firstOperand == 0 {
            firstOperand = Double(answerLabel.text ?? "0") ?? 0
            finalAnswer(ans: firstOperand)
            return
        }
        secondOperand = Double(answerLabel.text ?? "0") ?? 0
        firstOperand += secondOperand
        finalAnswer(ans: firstOperand)
        currentOperator = "+"
    }

    @IBAction private func subtractionAction(_ sender: Any) {
        currentOperator = "-"
        guard secondOperandChecker else {
            return
        }
        secondOperandChecker = false
        if firstOperand == 0 {
            firstOperand = Double(answerLabel.text ?? "0") ?? 0
            finalAnswer(ans: firstOperand)
            return
        }
        secondOperand = Double(answerLabel.text ?? "0") ?? 0
        firstOperand -= secondOperand
        finalAnswer(ans: firstOperand)
        currentOperator = "-"
    }

    @IBAction private func dotOperatorAction(_ sender: Any) {
        let text = answerLabel.text ?? ""
        guard text.contains(".") else {
            answerLabel.text = text + "."
            return
        }
    }

    @IBAction private func equalToAction(_ sender: UIButton) {
        if secondOperandChecker {
            secondOperand = Double(answerLabel.text ?? "0") ?? 0
            secondOperandChecker = false
        }
        let answer: Double
        switch currentOperator {
        case "/":
            answer = firstOperand / secondOperand
        case "*":
            answer = firstOperand * secondOperand
        case "+":
            answer = firstOperand + secondOperand
        case "-":
            answer = firstOperand - secondOperand
        default:
            answer = secondOperand
        }
        finalAnswer(ans: answer)
    }
}
extension CalculatorViewController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        scrollView.contentOffset.x = 0.0
    }
}
// extension UIColor {
//    func createOnePixelImage() -> UIImage? {
//        let size = CGSize(width: 1, height: 1)
//        UIGraphicsBeginImageContext(size)
//        defer { UIGraphicsEndImageContext() }
//        guard let context = UIGraphicsGetCurrentContext() else { return nil }
//        context.setFillColor(cgColor)
//        context.fill(CGRect(origin: .zero, size: size))
//        return UIGraphicsGetImageFromCurrentImageContext()
//    }
// }

// extension UIButton {
//    func setBackground(_ color: UIColor, for state: UIControl.State) {
//        setBackgroundImage(color.createOnePixelImage(), for: state)
//    }
// }

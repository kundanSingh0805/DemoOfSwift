//
//  HomePageViewController.swift
//  LoginPage
//
//  Created by IE15 on 07/11/23.
//

import UIKit

class HomeTabBarController: UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
    }
}

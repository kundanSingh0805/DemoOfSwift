//
//  UserDetailsViewController.swift
//  LoginPage
//
//  Created by IE15 on 24/11/23.
//

import UIKit
import Foundation

class UserDetailsViewController: UIViewController {
    @IBOutlet private var tableView: UITableView!
    let refreshControl = UIRefreshControl()

    public var allUsers: [UserDetails] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        refresh()
        accessDetails()
        self.tableView?.dataSource = self
        self.tableView?.delegate = self
        navigationTitle()
        self.navigationController?.navigationBar.tintColor = UIColor.black
    }

    private func navigationTitle() {
        let fontSize: CGFloat = 25.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "User Details"
    }
}

extension UserDetailsViewController {
    func accessDetails() {
        let url = URL(string: "https://jsonplaceholder.typicode.com/users")!
        let request = URLRequest(url: url)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print(error)
                DispatchQueue.main.async {
                    let alertController = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                    alertController.addAction(.init(title: "OK", style: .cancel))
                    self.present(alertController, animated: true)
                }
            } else if let data = data {
                guard let string = String(data: data, encoding: .utf8) else { return }
                // print(string)
                DispatchQueue.main.async {
                    if let jsonData = string.data(using: .utf8) {
                        do {
                            // Use JSONDecoder to decode the JSON data into YourStruct
                            let result: [UserDetails] = try JSONDecoder().decode([UserDetails].self, from: jsonData)
                            // Now, yourStructInstance contains the data from the JSON string
                            self.allUsers = result
                            self.tableView.reloadData()
                            //  print(self.allUsers.count)
                        } catch {
                            print("Error decoding JSON: \(error)")
                        }
                    } else {
                        print("Failed to convert JSON string to data.")
                    }
                }
            }
        }
        task.resume()
    }
}

extension UserDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return allUsers.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "UserDetailsTableViewCell",
                                                       for: indexPath) as? UserDetailsTableViewCell else {
            return UITableViewCell() }
        let userDetail = allUsers[indexPath.section]
        cell.userNameLabel.text = userDetail.username
        cell.nameLabel.text = userDetail.name
        cell.emailLabel.text = userDetail.email
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        guard let viewController =
                storyBoard.instantiateViewController(withIdentifier: "UserPostDetailsViewController")
                as? UserPostDetailsViewController else {
            return }
        let userDetail = allUsers[indexPath.section]
        viewController.userId = userDetail.id
        self.navigationController?.pushViewController(viewController, animated: true)
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "User"
    }

    func refresh() {
        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        tableView.addSubview(refreshControl)
    }

    @objc func refreshData() {
        let activityIndicator = UIActivityIndicatorView(style: .medium)
        activityIndicator.startAnimating()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: activityIndicator)
        refreshControl.endRefreshing()
        self.navigationItem.rightBarButtonItem = nil
    }
}

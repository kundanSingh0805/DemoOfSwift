//
//  PostsTableViewCell.swift
//  LoginPage
//
//  Created by IE15 on 27/11/23.
//

import UIKit

class PostsTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

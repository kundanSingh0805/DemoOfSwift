//
//  PostIdTableViewCell.swift
//  LoginPage
//
//  Created by IE15 on 24/11/23.
//

import UIKit

class UserDetailsTableViewCell: UITableViewCell {
    var postId: String?
    @IBOutlet weak var userNameLabel: UILabel!
   @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var userImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        userImage.layer.cornerRadius = 25
    }

}

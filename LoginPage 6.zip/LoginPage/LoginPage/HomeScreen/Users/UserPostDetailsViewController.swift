//
//  UserPostDetailsTableViewCell.swift
//  LoginPage
//
//  Created by IE15 on 24/11/23.
//

import UIKit

class UserPostDetailsViewController: UIViewController {
    let refreshControl = UIRefreshControl()
    var userPostDetails: [UserPostDetails] = []
    var userId: Int = 1
    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Post"
        accessDetails()
        tableView.dataSource = self
        tableView.delegate = self
        navigationTitle()
        self.navigationController?.navigationBar.tintColor = UIColor.black
    }

    private func navigationTitle() {
        let fontSize: CGFloat = 25.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Posts"
    }
}

extension UserPostDetailsViewController {
    func accessDetails() {
        let url = URL(string: "https://jsonplaceholder.typicode.com/posts?userId=\(userId)")!
        let request = URLRequest(url: url)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    let alertController = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                    alertController.addAction(.init(title: "OK", style: .cancel))
                    self.present(alertController, animated: true)
                }
            } else if let data = data {
                guard let string = String(data: data, encoding: .utf8) else { return }
                print(string)
                DispatchQueue.main.async {
                    if let jsonData = string.data(using: .utf8) {
                        do {
                            // Use JSONDecoder to decode the JSON data into YourStruct
                            let result: [UserPostDetails] = try JSONDecoder().decode([UserPostDetails].self, from: jsonData)
                            // Now, yourStructInstance contains the data from the JSON string
                            //  print(string)
                            self.userPostDetails = result
                            self.tableView.reloadData()
                            //  print(self.allUsers.count)
                        } catch {
                            print("Error decoding JSON: \(error)")
                        }
                    } else {
                        print("Failed to convert JSON string to data.")
                    }
                }
            }
        }
        task.resume()
    }
}
extension UserPostDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return userPostDetails.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "UserPostDetailTableViewCell",
                                                       for: indexPath) as? UserPostDetailTableViewCell else {
            return UITableViewCell() }
        let userDetail = userPostDetails[indexPath.section]

        cell.titleLabel.text = userDetail.title
        cell.bodyLabel.text = userDetail.body
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "  "
    }

    func refresh() {
        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        tableView.addSubview(refreshControl)
    }
    @objc func refreshData() {
        let activityIndicator = UIActivityIndicatorView(style: .medium)
        activityIndicator.startAnimating()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: activityIndicator)
        refreshControl.endRefreshing()
        self.navigationItem.rightBarButtonItem = nil
    }
}

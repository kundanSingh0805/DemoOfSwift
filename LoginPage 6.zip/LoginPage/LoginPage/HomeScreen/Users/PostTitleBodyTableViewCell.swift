//
//  PostTitleBodyTableViewCell.swift
//  LoginPage
//
//  Created by IE15 on 27/11/23.
//

import UIKit

class PostTitleBodyTableViewCell: UITableViewCell {

    @IBOutlet public var titleLabel: UILabel!
    @IBOutlet public var bodyLabel: UILabel!
    @IBOutlet weak var postImage: UIImageView!
    @IBOutlet weak var likeButton: UIButton!
    private var isLike = true
    override func awakeFromNib() {
        super.awakeFromNib()
        postImage.layer.cornerRadius = 8
    }
    @IBAction func likeButtonAction(_ sender: Any) {
        if isLike {
            let image = UIImage(named: "UnLike_Icon.jpg")
            likeButton.setImage(image, for: .normal)
        } else {
            let image = UIImage(named: "Like_Icon.jpg")
            likeButton.setImage(image, for: .normal)
        }
        isLike = !isLike
    }
//    @IBAction func imageSaveButtonAction(_ sender: Any) {
//
//    }
}

//
//  userPostDetailTableViewCell.swift
//  LoginPage
//
//  Created by IE15 on 24/11/23.
//

import UIKit

class UserPostDetailTableViewCell: UITableViewCell {

    @IBOutlet public var titleLabel: UILabel!
    @IBOutlet public var bodyLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

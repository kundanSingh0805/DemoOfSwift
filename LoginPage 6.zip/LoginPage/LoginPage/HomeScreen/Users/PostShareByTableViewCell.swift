//
//  PostShareByTableViewCell.swift
//  LoginPage
//
//  Created by IE15 on 28/11/23.
//

import UIKit

class PostShareByTableViewCell: UITableViewCell {
    @IBOutlet public var nameLabel: UILabel!
    @IBOutlet public var emailLabel: UILabel!
    @IBOutlet public var bodyLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}

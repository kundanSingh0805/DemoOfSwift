//
//  PostsViewController.swift
//  LoginPage
//
//  Created by IE15 on 27/11/23.
//

import UIKit

class PostsViewController: UIViewController {
    @IBOutlet private var tableView: UITableView!
    @IBOutlet private var postButton: UIButton!

    let refreshControl = UIRefreshControl()
    public var allPosts: [PostDetails] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        refresh()
        accessDetails()
        self.tableView?.dataSource = self
        self.tableView?.delegate = self
        navigationTitle()
        postButton.layer.cornerRadius = 8
        self.navigationController?.navigationBar.tintColor = UIColor.black
    }
    
    private func navigationTitle() {
        let fontSize: CGFloat = 25.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Posts"
    }
    
    @IBAction func postButtonAction(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
       let viewController =
                storyBoard.instantiateViewController(withIdentifier: "NewPostViewController") 
        self.navigationController?.pushViewController(viewController, animated: true)
    }
}

extension PostsViewController {
    func accessDetails() {
        let url = URL(string: "https://jsonplaceholder.typicode.com/posts")!
        let request = URLRequest(url: url)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print(error)

                DispatchQueue.main.async {
                let alertController = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                    alertController.addAction(.init(title: "OK", style: .cancel))
                    self.present(alertController, animated: true)
                }
            } else if let data = data {
                guard let string = String(data: data, encoding: .utf8) else { return }
                // print(string)
                DispatchQueue.main.async {
                    if let jsonData = string.data(using: .utf8) {
                        do {
                            // Use JSONDecoder to decode the JSON data into YourStruct
                            let result: [PostDetails] = try JSONDecoder().decode([PostDetails].self, from: jsonData)
                            // Now, yourStructInstance contains the data from the JSON string
                            self.allPosts = result
                            self.tableView.reloadData()
                            //  print(self.allUsers.count)
                        } catch {
                            print("Error decoding JSON: \(error)")
                        }
                    } else {
                        print("Failed to convert JSON string to data.")
                    }
                }
            }
        }
        task.resume()
    }
}

extension PostsViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return allPosts.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PostTitleBodyTableViewCell",
                                                       for: indexPath) as? PostTitleBodyTableViewCell else {
            return UITableViewCell() }
        let postDetail = allPosts[indexPath.section]
        cell.titleLabel.text = postDetail.title
        cell.bodyLabel.text = postDetail.body
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        guard let viewController =
                storyBoard.instantiateViewController(withIdentifier: "PostShareByViewController")
                as? PostShareByViewController else {
            return }
        let userDetail = allPosts[indexPath.section]
        viewController.userId = userDetail.id
        self.navigationController?.pushViewController(viewController, animated: true)
    }

//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        return "post"
//    }

    func refresh() {
        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        tableView?.addSubview(refreshControl)
    }
    @objc func refreshData() {
        let activityIndicator = UIActivityIndicatorView(style: .medium)
        activityIndicator.startAnimating()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: activityIndicator)
        refreshControl.endRefreshing()
        self.navigationItem.rightBarButtonItem = nil
    }
}

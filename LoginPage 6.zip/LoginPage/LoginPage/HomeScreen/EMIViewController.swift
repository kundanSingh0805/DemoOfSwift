//
//  EMIViewController.swift
//  Demo
//
//  Created by IE15 on 31/10/23.
//

import UIKit

final class EMIViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet private var amountTextField: UITextField!
    @IBOutlet private var interestTextField: UITextField!
    @IBOutlet private var expectedEmiTextField: UITextView!
    @IBOutlet private var amountSlider: UISlider!
    @IBOutlet private var amountStepper: UIStepper!
    @IBOutlet private var interestStepper: UIStepper!
    @IBOutlet private var interestSlider: UISlider!
    @IBOutlet private var tenureTextField: UITextField!
    @IBOutlet private var tenureStepper: UIStepper!
    @IBOutlet private var tenureSlider: UISlider!
    @IBOutlet private var expectedEmiValue: UITextView!
    @IBOutlet private var amountMassage: UILabel!
    @IBOutlet private var tenureMassage: UILabel!
    @IBOutlet private var interestMassage: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationTitle()
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0,
                                                                  width: UIScreen.main.bounds.width, height: 50))
        doneToolbar.barStyle = .default
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self,
                                                    action: #selector(self.doneButtonAction))
        let items = [flexSpace, done]
        doneToolbar.items = items
        doneToolbar.sizeToFit()

        amountTextField.inputAccessoryView = doneToolbar
        interestTextField.inputAccessoryView = doneToolbar
        tenureTextField.inputAccessoryView = doneToolbar
        navigationItem.leftBarButtonItem?.tintColor = UIColor.black
    }
     
    @objc func doneButtonAction() {
        amountTextField.resignFirstResponder()
        interestTextField.resignFirstResponder()
        tenureTextField.resignFirstResponder()
    }

    private func navigationTitle() {
        let fontSize: CGFloat = 25.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Emi Calculator"
    }

    private func expectedEmi() {
        let amount: Float = Float(amountTextField.text ?? "0") ?? 0
        let interest: Float = Float(interestTextField.text ?? "0") ?? 0
        let tenure: Float = Float(tenureTextField.text ?? "0") ?? 0
        let exEmVa = Float(Int(((amount * interest * tenure) / 100) * 100)) / 100
        expectedEmiValue.text = String(exEmVa)
    }

    @IBAction private func amountTextFieldAction(_ sender: UITextField) {
        amountMassage.text = ""
        if let value = sender.text, let valueInt = Int(value) {
            if valueInt > 100000 {
                amountTextField.text = "100000"
                amountMassage.text = "You are typing out of range"
            } else if valueInt < 1000 { amountTextField.text = "100"
                amountMassage.text = "You are typing out of range"
            }
            amountSlider.value = Float(value) ?? 0
            amountStepper.value = Double(value) ?? 0
            expectedEmi()
        }
    }

    @IBAction private func amountStepper(_ sender: UIStepper) {
        amountMassage.text = ""
        amountSlider.value = Float(sender.value)
        amountTextField.text = String(Int(amountSlider.value))
        expectedEmi()
    }

    @IBAction private func amountSliderAction(_ sender: UISlider) {
        amountMassage.text = ""
        amountStepper.value = Double(sender.value)
        amountTextField.text = String(Int(sender.value))
        expectedEmi()
    }

    @IBAction private func interestStepperAction(_ sender: UIStepper) {
        interestMassage.text = ""
        let temp = Float(Int(Double(sender.value * 10 )) )
        interestTextField.text = String(temp / 10)
        interestSlider.value = Float(temp / 10)
        expectedEmi()
    }

    @IBAction private func interestTextFieldAction(_ sender: UITextField) {
        interestMassage.text = ""
        if let value = sender.text {
            var temp: Float! = 0
            if !value.isEmpty {
                temp = Float(value)
            }
            if temp > 18 {
                interestTextField.text = "18"
                interestMassage.text = "You are typing out of range"
            } else if temp < 6 {
                interestTextField.text = "0"
                interestMassage.text = "You are typing out of range"
            }
            interestSlider.value = Float(value) ?? 0
            interestStepper.value = Double(value) ?? 0
            expectedEmi()
        }
    }

    @IBAction private func interestSliderAction(_ sender: UISlider) {
        interestMassage.text = ""
        let temp = Float(Int(Double(sender.value * 10 )) )
        interestTextField.text = String(temp / 10)
        interestStepper.value = Double(sender.value)
        expectedEmi()
    }

    @IBAction private func tenureTextFieldFun(_ sender: UITextField) {
        tenureMassage.text = ""
        var temp: Float! = 0

        if let value = sender.text {
            if !value.isEmpty {
                temp = Float(value)
            }
            if temp > 6 {
                tenureTextField.text = "6"
                tenureMassage.text = "You are typing out of range"
            } else if temp < 1 {
                tenureTextField.text = "0"
                tenureMassage.text = "You are typing out of range"
            }
            tenureSlider.value = Float(value) ?? 0
            tenureStepper.value = Double(value) ?? 0
            expectedEmi()

            if value.contains(".") {
            guard let withoutDecimal = Int(value.substring(to: value.index(before: value.endIndex)))
                else {
                return }
                tenureTextField.text = String(withoutDecimal)
                tenureMassage.text = "Decimal Value Not allowed"
            }
        }
    }

    @IBAction private func tenureStepperFun(_ sender: UIStepper) {
        tenureMassage.text = ""
        let value = Int(sender.value)
        tenureTextField.text = String(value)
        tenureSlider.value = Float(value)
        expectedEmi()
    }

    @IBAction private func tenureSliderFun(_ sender: UISlider) {
        tenureMassage.text = ""
        let temp = Int(sender.value)
        tenureTextField.text = String(temp)
        tenureStepper.value = Double(sender.value)
        expectedEmi()
    }
}

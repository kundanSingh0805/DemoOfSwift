import UIKit
import AVFoundation
import AVKit

class NewPostViewController: UIViewController, UINavigationControllerDelegate, UIVideoEditorControllerDelegate {
    @IBOutlet weak var showImageByButton: UIButton!
    @IBOutlet weak var descriptionBorderTextView: BorderTextView!
    @IBOutlet weak var shareButton: UIButton!

    let imagePickerController = UIImagePickerController()
    var videoURL: NSURL? =
    URL(string: "https://media.istockphoto.com/id/1417774215/video/fresh-green-tree-with-beautiful-sunlight.mp4?s=mp4-640x640-is&k=20&c=HEIxivEB4HxiaVcRL8VMxdGdyxBoBonc2YGYakPG_Ig=")
    as NSURL?
    var imageURL: UIImage?
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePickerController.delegate = self
        shareButton.layer.cornerRadius = 8
        navigationTitle()
        let image = createThumbnailOfVideoFromFileURL(videoURL: videoURL ?? NSURL())
        showImageByButton.setImage(image, for: .normal)
        showImageByButton.contentVerticalAlignment = .fill
        showImageByButton.contentHorizontalAlignment = .fill
        showImageByButton.layer.cornerRadius = 112.5
        showImageByButton.clipsToBounds = true
        self.navigationController?.navigationBar.tintColor = UIColor.black
     }
 
    private func navigationTitle() {
        let fontSize: CGFloat = 25.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "New Post"
    }
    @IBAction func showImageAndVideoButtonAction(_ sender: Any) {
        if imageURL != nil {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let viewController =
                storyboard.instantiateViewController(withIdentifier: "ShowYourImageViewController")
                as? ShowYourImageViewController {
                viewController.image = imageURL
                navigationController?.pushViewController(viewController, animated: true) }
        } else if let url = videoURL {
            let player = AVPlayer(url: url as URL)
            let controller=AVPlayerViewController()
            controller.player=player
            controller.view.frame = self.view.frame
            self.view.addSubview(controller.view)
            self.addChild(controller)
            // player.play()
        }
    }

    @IBAction func newImageAndVideoSelectButtonAction(_ sender: Any) {
        let massage = "Select Image From"
        let alertController = UIAlertController(title: "Image", message: massage, preferredStyle: .actionSheet)
        let byCamera = UIAlertAction(title: "Camera", style: UIAlertAction.Style.default, handler: { _ in
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                self.imagePickerController.sourceType = .camera
            } else {
                print("Camera not available")
            }})
        let byGallery = UIAlertAction(title: "Gallery", style: UIAlertAction.Style.default, handler: { _ in
            self.imagePickerController.sourceType = .photoLibrary
            //  self.imagePickerController.delegate = self
            self.imagePickerController.mediaTypes = ["public.image", "public.movie"]
            self.present(self.imagePickerController, animated: true, completion: nil)
        })
        let cancel = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil)
        alertController.addAction(byCamera)
        alertController.addAction(byGallery)
        alertController.addAction(cancel)
        present(alertController, animated: true)
    }

    @IBAction func shareButtonAction(_ sender: Any) {
        let text = "This is the text...."
        let image: UIImage = imageURL ?? UIImage()
        // let myWebsite = NSURL(string:"https://stackoverflow.com/users/4600136/mr-javed-multani?tab=profile")
        let shareAll = [text, image] as [Any]
        let activityViewController = UIActivityViewController(activityItems: shareAll, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
        self.present(activityViewController, animated: true, completion: nil)
    }

    @IBAction func videoEditButtonAction(_ sender: Any) {
        if let video = videoURL?.path {
            if UIVideoEditorController.canEditVideo(atPath: video) {
                let editController = UIVideoEditorController()
                editController.videoPath = video
                editController.delegate = self
                present(editController, animated: true) }
        }
    }
}

extension NewPostViewController {
    func createThumbnailOfVideoFromFileURL(videoURL: NSURL) -> UIImage? {
        let asset = AVAsset(url: videoURL as URL)
        let assetImgGenerate = AVAssetImageGenerator(asset: asset)
        assetImgGenerate.appliesPreferredTrackTransform = true
        let time = CMTimeMakeWithSeconds(Float64(1), preferredTimescale: 100)
        do {
            let img = try assetImgGenerate.copyCGImage(at: time, actualTime: nil)
            let thumbnail = UIImage(cgImage: img)
            return thumbnail
        } catch {
            return UIImage(named: "ico_placeholder")
        }
    }

}
extension NewPostViewController: UIImagePickerControllerDelegate {
    public func imagePickerController(_ picker: UIImagePickerController,
                                      didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let image = info[.originalImage] as? UIImage {
            showImageByButton.setImage(image, for: .normal)
            imageURL = image

        } else {
            imageURL = nil
            videoURL = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerReferenceURL") ] as? NSURL
             let image = createThumbnailOfVideoFromFileURL(videoURL: videoURL ?? NSURL())
            showImageByButton.setImage(image, for: .normal)
        }
        picker.dismiss(animated: true, completion: nil)
    }
}

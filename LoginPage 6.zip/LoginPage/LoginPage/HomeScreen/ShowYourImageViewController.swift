//
//  ShowYourVideoAndImageViewController.swift
//  LoginPage
//
//  Created by IE15 on 21/11/23.
//

import UIKit
import AVKit
class ShowYourImageViewController: UIViewController {
    @IBOutlet weak var selectedUiImageView: UIImageView!
    @IBOutlet var pinchGesture: UIPinchGestureRecognizer!
    @IBOutlet var rotationGesture: UIRotationGestureRecognizer!
    @IBOutlet var tapGesture: UITapGestureRecognizer!
    @IBOutlet var penGesture: UIPanGestureRecognizer!
    @IBOutlet weak var likeDislikeUiImageView: UIImageView!

    var image: UIImage?
    private var isLike: Bool = false
    var playerController = AVPlayerViewController()

    override func viewDidLoad() {
        super.viewDidLoad()
        selectedUiImageView.image = image
    }

    @IBAction func pinchGestureAction(_ sender: UIPinchGestureRecognizer) {
        let scaleResult = sender.view?.transform.scaledBy(x: sender.scale, y: sender.scale)
        guard let scale = scaleResult, scale.a > 1, scale.d > 1 else { return }
        sender.view?.transform = scale
        sender.scale = 1
    }

    @IBAction func rotationGestureAction(_ sender: UIRotationGestureRecognizer) {
        guard rotationGesture.view != nil else { return }
        if rotationGesture.state == .began || rotationGesture.state == .changed {
            rotationGesture.view?.transform = rotationGesture.view!.transform.rotated(by: rotationGesture.rotation)
            rotationGesture.rotation = 0
        }
    }

    @IBAction func tapGestureAction(_ sender: UITapGestureRecognizer) {
        if isLike {
            likeDislikeUiImageView.image = UIImage(named: "unlike")
        } else {
            likeDislikeUiImageView.image = UIImage(named: "like")
        }
        isLike = !isLike
    }

    @IBAction func penGestureAction(_ sender: UIPanGestureRecognizer) {
        guard let panView = sender.view else { return }
        let translation = sender.translation(in: view)
        panView.center = CGPoint(x: panView.center.x + translation.x, y: panView.center.y + translation.y)
        sender.setTranslation(.zero, in: view)
    }
}

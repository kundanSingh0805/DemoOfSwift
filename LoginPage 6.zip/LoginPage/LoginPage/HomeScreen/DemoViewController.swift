//
//  DemoViewController.swift
//  LoginPage
//
//  Created by IE15 on 29/11/23.
//

import UIKit

class DemoViewController: UIViewController {
    @IBOutlet private var calculatorButton: UIButton!
    @IBOutlet private var emiCalculatorButton: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationTitle()
    }

    private func navigationTitle() {
        let fontSize: CGFloat = 25.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Demo"
    }
    @IBAction func calculatorButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController =
        storyboard.instantiateViewController(withIdentifier: "CalculatorViewController")
        navigationController?.pushViewController(viewController, animated: true)
        calculatorButton.layer.cornerRadius = 10
        emiCalculatorButton.layer.cornerRadius = 10
    }
    @IBAction func emiCalculatorButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController =
        storyboard.instantiateViewController(withIdentifier: "EMIViewController")
        navigationController?.pushViewController(viewController, animated: true)
    }
}

//
//  PrivacyPolicyWebView.swift
//  LoginPageUITests
//
//  Created by IE15 on 15/11/23.
//

import UIKit

class PrivacyPolicyWebView: UIWebView {
}

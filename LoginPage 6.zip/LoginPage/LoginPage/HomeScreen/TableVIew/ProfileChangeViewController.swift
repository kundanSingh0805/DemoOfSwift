//
//  ProfileChangeViewController.swift
//  LoginPage
//
//  Created by IE15 on 27/11/23.
//

import UIKit

class ProfileChangeViewController: UIViewController, UINavigationControllerDelegate {
    let imagePickerController = UIImagePickerController()
    var userImage: UIImageView!

    @IBOutlet private var userUIImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        userUIImageView.layer.cornerRadius = 51.5
        imagePickerController.delegate = self
        userUIImageView.image = userImage.image
        self.navigationController?.navigationBar.tintColor = UIColor.black
    }

    @IBAction func changeProfileImageButtonAction(_ sender: Any) {
        alert()
    }

    func alert() {
        let massage = "Select Image From"
        let alertController = UIAlertController(title: "Image", message: massage, preferredStyle: .actionSheet)
        let byCamera = UIAlertAction(title: "Camera", style: UIAlertAction.Style.default, handler: { _ in
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                self.imagePickerController.sourceType = .camera
            } else {
                print("Camera not available")
            }})
        let byGallery = UIAlertAction(title: "Gallery", style: UIAlertAction.Style.default, handler: { _ in
            self.imagePickerController.sourceType = .photoLibrary
            self.present(self.imagePickerController, animated: true, completion: nil)
        })
        let cancel = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil)
        alertController.addAction(byCamera)
        alertController.addAction(byGallery)
        alertController.addAction(cancel)
        present(alertController, animated: true)
    }
}
extension ProfileChangeViewController: UIImagePickerControllerDelegate {
    public func imagePickerController(_ picker: UIImagePickerController,
                                      didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let image = info[.originalImage] as? UIImage {
            userUIImageView?.image = image
            userImage.image = image
        } else {
            print("Not found")
        }
        picker.dismiss(animated: true, completion: nil)
    }
}

//
//  QueryAndSolutionTableViewCell.swift
//  LoginPageUITests
//
//  Created by IE15 on 15/11/23.
//

import UIKit

final class QueryAndSolutionTableViewCell: UITableViewCell {
    @IBOutlet public var queryLabel: UILabel!
    @IBOutlet public var solutionLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}

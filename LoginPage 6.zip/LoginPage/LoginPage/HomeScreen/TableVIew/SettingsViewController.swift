//
//  TableViewController.swift
//  LoginPageUITests
//
//  Created by IE15 on 10/11/23.
//

import Foundation
import UIKit

public struct SectionView {
    public var section: String
    public var list: [String]
}

public class SettingsViewController: UIViewController, UINavigationControllerDelegate {
    var userImage: UIImageView!
    @IBOutlet private var tableView: UITableView!

    var sections = [
        SectionView(section: "Profile", list: ["Kundan Singh"]),
        SectionView(section: "Security", list: ["Privacy Policy","Terms"]),
        SectionView(section: "Other", list: ["About"]),
        SectionView(section: "Help", list: ["Help Center"]),
        SectionView(section: "Logout", list: ["Logout"])
    ]

    public override func viewDidLoad() {
        super.viewDidLoad()
        navigationTitle()
        tableView?.delegate = self
        tableView?.dataSource = self
    }

    private func navigationTitle() {
        let fontSize: CGFloat = 25.0
        let titleTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: fontSize, weight: .bold)
        ]
        navigationController?.navigationBar.titleTextAttributes = titleTextAttributes
        self.title = "Setting"
    }
}

extension SettingsViewController: UITableViewDelegate, UITableViewDataSource {
    public func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }

    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let sectionView = sections[section]
        return sectionView.list.count
    }

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 && indexPath.row == 0 {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "UserSectionTableViewCell",
                                                           for: indexPath) as? UserSectionTableViewCell else {
                return UITableViewCell() }
            let setting = sections[indexPath.section]
            cell.userNameTexField.text = setting.list[indexPath.row]
            userImage = cell.userImage
            return cell
        } else {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "AppFunctionalityTableViewCell", for: indexPath) as? AppFunctionalityTableViewCell else {
                return UITableViewCell() }
            let setting = sections[indexPath.section]
            cell.functionalityTextField.text = setting.list[indexPath.row]
        
            if indexPath.section == 4 && indexPath.row == 0 {
                cell.functionalityTextField.textColor = UIColor.red
            }
            return cell
        }
    }
    public func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let sectionView = sections[section]
        return sectionView.section
    }

    public func tableView(_ tableView: UITableView,  didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 && indexPath.row == 0 {
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            guard let viewController =
                    storyBoard.instantiateViewController(withIdentifier: "ProfileChangeViewController")
                    as? ProfileChangeViewController else { return }
            viewController.userImage = userImage
            self.navigationController?.pushViewController(viewController, animated: true)
        }
        if indexPath.section == 1 && indexPath.row == 0 {
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            guard let privacyPolicy =
                    storyBoard.instantiateViewController(withIdentifier: "PrivacyPolicyViewController")
                    as? PrivacyPolicyViewController else {
                return }
            privacyPolicy.forUrl = "https://www.facebook.com/privacy/policy/"
            self.navigationController?.pushViewController(privacyPolicy, animated: true)
        }
        if indexPath.section == 1 && indexPath.row == 1 {
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            guard let privacyPolicy =
                    storyBoard.instantiateViewController(withIdentifier: "PrivacyPolicyViewController")
                    as? PrivacyPolicyViewController else {
                return }
            privacyPolicy.forUrl = "https://www.facebook.com/help/581066165581870"
            self.navigationController?.pushViewController(privacyPolicy, animated: true)
        }
        if indexPath.section == 2 && indexPath.row == 0 {
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            guard  let privacyPolicy =
                    storyBoard.instantiateViewController(withIdentifier: "AboutViewController")
                    as? AboutViewController else {
                return }
            self.navigationController?.pushViewController(privacyPolicy, animated: true)
        }
        if indexPath.section == 3 && indexPath.row == 0 {
            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            guard let helpCenter =
                    storyBoard.instantiateViewController(withIdentifier: "HelpCenterViewController")
                    as? HelpCenterViewController else {
                return }
            
            self.navigationController?.pushViewController(helpCenter, animated: true)
        }
        if indexPath.section == 4 && indexPath.row == 0 {
            alertMassage()
        }
    }
}

extension SettingsViewController {
    //    private func pushViewControllerInNavigationController(let viewController:UIViewController){
    //
    //    }
    private func alertMassage() {
        let massage = "You will be returned to the Login  screen"
        let alertController = UIAlertController(title: "Log Out", message: massage, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in }))
        let logOutActionButton = UIAlertAction(title: "Log out", style: .default, handler: { _ in
            // let storyboard = UIStoryboard(name: "Main", bundle: nil)
            //   let signInViewController = storyboard.instantiateViewController(withIdentifier: "SignInViewController")
            guard let selfNavigationController = self.navigationController else {
                return }
            for controller in selfNavigationController.viewControllers as Array
            where controller.isKind(of: SignInViewController.self) {
                selfNavigationController.popToViewController(controller, animated: true)
                break
            }
        })
        logOutActionButton.setValue(UIColor.red, forKey: "titleTextColor")
        alertController.addAction(logOutActionButton)
        self.present(alertController, animated: true)
    }
}

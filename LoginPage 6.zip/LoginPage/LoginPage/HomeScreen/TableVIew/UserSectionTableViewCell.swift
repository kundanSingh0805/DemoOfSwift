//
//  UserSectionTableViewCell.swift
//  LoginPageUITests
//
//  Created by IE15 on 10/11/23.
//

import UIKit

protocol UserSectionTableViewCellDelegate: AnyObject {
    func alert(userImage: UIImageView)
}

class UserSectionTableViewCell: UITableViewCell {
    var userSectionTableViewCellDelegate: UserSectionTableViewCellDelegate?
    @IBOutlet public var userImage: UIImageView!
    @IBOutlet public var userNameTexField: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        userImage.layer.cornerRadius = 51.5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    @IBAction private func addImageOnPress(_ sender: UIButton) {
        userSectionTableViewCellDelegate?.alert(userImage: userImage)
    }
}

//
//  HelpCenterViewController.swift
//  LoginPageUITests
//
//  Created by IE15 on 15/11/23.
//

import UIKit

struct Section {
    var query: String
    var solution: String
    var isShow: Bool
}

class HelpCenterViewController: UIViewController {
    @IBOutlet private var tableView: UITableView!

    var sections = [
        Section(query: "What is the dollar explained?",
                solution: "The USD (United States dollar) is the official currency of the United States of America.",
                isShow: false),
        Section(query: "What is Benefit",
                solution: "helpful or good effect, or something intended",
                isShow: false),
        Section(query: "What is the dollar explained?",
                solution: "The USD (United States dollar) is the official currency of the United States of America.",
                isShow: false)]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.tintColor = UIColor.black
        tableView.delegate = self
        tableView.dataSource = self

        let backButton = UIBarButtonItem()
        backButton.title = "Setting"
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
    }
}

extension HelpCenterViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "QueryAndSolutionTableViewCell",
                                                       for: indexPath) as? QueryAndSolutionTableViewCell else {
            return UITableViewCell() }

        let section = sections[indexPath.section]
        cell.queryLabel.text = section.query
        cell.solutionLabel.text = section.solution
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        sections[indexPath.section].isShow = !sections[indexPath.section].isShow
        tableView.reloadRows(at: [indexPath], with: .automatic)
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let section = sections[indexPath.section]
        if section.isShow {
            return 150
        } else {
            return 40
        }
    }
}

//
//  PrivacyPolicyViewController.swift
//  LoginPageUITests
//
//  Created by IE15 on 15/11/23.
//

import UIKit
import WebKit

class PrivacyPolicyViewController: UIViewController {
    @IBOutlet private var webView: WKWebView!
    @IBOutlet private var actitvityIndicator: UIActivityIndicatorView!

    var forUrl: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.tintColor = UIColor.black
        let backButton = UIBarButtonItem()
        backButton.title = "Setting"
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton

        webView.navigationDelegate = self

        actitvityIndicator.startAnimating()
        loadAddress()
    }

    func loadAddress() {
        guard let url = URL(string: forUrl ?? "")
        else { return }
        webView.load( URLRequest(url: url) )
    }
}

extension PrivacyPolicyViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        actitvityIndicator.stopAnimating()
        actitvityIndicator.isHidden = true
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        actitvityIndicator.stopAnimating()
        actitvityIndicator.isHidden = true
    }
}

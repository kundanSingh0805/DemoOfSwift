//
//  FirstPageViewController.swift
//  LoginPage
//
//  Created by IE15 on 04/11/23.
//

import UIKit

class FirstPageViewController: UIViewController {

    @IBOutlet private var image: UIImageView!
    @IBOutlet private var titleLabel: UILabel!
    @IBOutlet private var subTitleLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

    }
}

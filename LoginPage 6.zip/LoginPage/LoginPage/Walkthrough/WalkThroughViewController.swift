//
//  RootViewController.swift
//  LoginPage
//
//  Created by IE15 on 04/11/23.
//

import UIKit

final class WalkThroughViewController: UIViewController {
    private var pageViewController: UIPageViewController?
    // @IBOutlet private var skipButton: UIButton?
    @IBOutlet private var pageControl: UIPageControl?
    @IBOutlet private var loginButton: UIButton?

    private var index: Int = 1
    private var viewControllerList: [UIViewController] = {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let firstPageViewController = storyBoard.instantiateViewController(withIdentifier: "FirstPageViewController")
        let secondPageViewController = storyBoard.instantiateViewController(withIdentifier: "SecondPageViewController")
        let thirdPageViewController = storyBoard.instantiateViewController(withIdentifier: "ThirdPageViewController")
        return [firstPageViewController, secondPageViewController, thirdPageViewController]
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        pageControl?.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
        loginButton?.tintColor = UIColor(named: "YellowColor")
        print(viewControllerList)
        print(viewControllerList)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "PageViewController" {
            pageViewController = segue.destination as? UIPageViewController
            pageViewController?.dataSource = self
            pageViewController?.delegate = self
            if let firstViewController = viewControllerList.first {
                pageViewController?.setViewControllers([firstViewController],
                                                       direction: .forward, animated: true, completion: nil)
            }
        }
    }

    @IBAction private func loginButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "SignInViewController")
        navigationController?.pushViewController(viewController, animated: true)
    }
}

extension WalkThroughViewController: UIPageViewControllerDelegate {
    func pageViewController(_ pageViewController: UIPageViewController,
                            didFinishAnimating finished: Bool,
                            previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if let currentPageViewController = pageViewController.viewControllers?.first {
            let index = viewControllerList.firstIndex(of: currentPageViewController)!
            if index == 0 {
                loginButton?.tintColor = UIColor(named: "YellowColor")
                pageControl?.currentPageIndicatorTintColor = UIColor(named: "YellowColor")
                pageControl?.pageIndicatorTintColor = UIColor(named: "LightYellowColor")
            } else if index == 1 {
                loginButton?.tintColor = UIColor.brown
                pageControl?.currentPageIndicatorTintColor = UIColor.brown
                pageControl?.pageIndicatorTintColor = UIColor(named: "LightBrownColor")
            } else if index == 2 {
                loginButton?.tintColor = UIColor.blue
                pageControl?.currentPageIndicatorTintColor = UIColor.blue
                pageControl?.pageIndicatorTintColor = UIColor(named: "LightBlueColor")
            }
            pageControl?.currentPage = index
        }
    }
}

extension WalkThroughViewController: UIPageViewControllerDataSource {
    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let vcIndex = viewControllerList.firstIndex(of: viewController) else {
            return nil }
        let nextIndex = vcIndex + 1
        guard viewControllerList.count != nextIndex else {
//            if let viewController = viewController as? ThirdPageViewController {
//                if nextIndex == 3 {
//                    navigateToNextPage()
//                }
//            }
            return nil
        }
        return viewControllerList[nextIndex]
    }

    func pageViewController( _ pageViewController: UIPageViewController,
                             viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let vcIndex = viewControllerList.firstIndex (of: viewController) else {return nil}
        let previousIndex = vcIndex - 1
        guard previousIndex >= 0 else {return nil}
        guard viewControllerList.count > previousIndex else {return nil}
        return viewControllerList[previousIndex]
    }

       private func navigateToNextPage() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "SignInViewController")
        navigationController?.pushViewController(viewController, animated: true)
    }
}

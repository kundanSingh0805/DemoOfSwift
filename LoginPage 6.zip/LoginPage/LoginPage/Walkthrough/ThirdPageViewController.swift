//
//  ThirdPageViewController.swift
//  LoginPage
//
//  Created by IE15 on 04/11/23.
//

import UIKit

class ThirdPageViewController: UIViewController {
    @IBOutlet private var image: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        //        let yourImage: UIImage = UIImage(named: "emotionalInte.png")!
        //                   image.image = yourImage
    }
}

//
//  SecondPageViewController.swift
//  LoginPage
//
//  Created by IE15 on 04/11/23.
//

import UIKit

class SecondPageViewController: UIViewController {
    @IBOutlet private var image: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        //        var yourImage: UIImage = UIImage(named: "verbalComm.png")!
        //                   image.image = yourImage
    }
}

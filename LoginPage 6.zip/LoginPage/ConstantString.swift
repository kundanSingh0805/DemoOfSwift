//
//  ConstantString.swift
//  LoginPage
//
//  Created by IE15 on 20/11/23.
//

import Foundation

public struct ConstantString {
    static let menuAlreadyAssignedMessage = """
%@ was already assigned to the %@ of %@. When using multiple SideMenuManagers
 you may want to use new instances of SideMenuNavigationController instead of
existing instances to avoid crashes if the menu is presented more than once.
"""
}
